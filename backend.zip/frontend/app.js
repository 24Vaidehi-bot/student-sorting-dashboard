/**
 * app.js  —  Student Sorting Dashboard
 *
 * Responsibilities:
 *  1. Form handling — add students via POST /students
 *  2. Render student table from GET /students
 *  3. Trigger sort via GET /sort/merge or GET /sort/quick
 *  4. Render sorted results with highlight animation
 *  5. Bar-chart visualization of sorted marks
 *  6. Toast notifications, slider sync, demo data
 *
 * API base URL — change port if needed
 */

const API = 'http://localhost:3000';

/* ── Demo dataset ────────────────────────────────────────────── */
const DEMO_STUDENTS = [
  { name: 'Alice Sharma',   roll: 101, marks: 92 },
  { name: 'Bob Mehta',      roll: 102, marks: 78 },
  { name: 'Carol Singh',    roll: 103, marks: 85 },
  { name: 'David Patel',    roll: 104, marks: 55 },
  { name: 'Eva Nair',       roll: 105, marks: 97 },
  { name: 'Frank Joshi',    roll: 106, marks: 63 },
];

/* ── Cached DOM references ───────────────────────────────────── */
const form            = document.getElementById('addStudentForm');
const nameInput       = document.getElementById('studentName');
const rollInput       = document.getElementById('rollNumber');
const marksInput      = document.getElementById('marks');
const marksSlider     = document.getElementById('marksSlider');
const marksDisplay    = document.getElementById('marksDisplay');
const formError       = document.getElementById('formError');
const addBtn          = document.getElementById('addStudentBtn');
const loadDemoBtn     = document.getElementById('loadDemoBtn');
const clearAllBtn     = document.getElementById('clearAllBtn');
const mergeSortBtn    = document.getElementById('mergeSortBtn');
const quickSortBtn    = document.getElementById('quickSortBtn');
const tableBody       = document.getElementById('studentTableBody');
const studentCount    = document.getElementById('studentCount');
const statusBar       = document.getElementById('statusBar');
const statusText      = document.getElementById('statusText');
const vizPanel        = document.getElementById('vizPanel');
const vizTitle        = document.getElementById('vizTitle');
const vizBars         = document.getElementById('vizBars');
const vizSortInfo     = document.getElementById('vizSortInfo');
const closeVizBtn     = document.getElementById('closeVizBtn');
const toast           = document.getElementById('toast');

/* ── State ───────────────────────────────────────────────────── */
let currentSortAlgo = null;   /* 'merge' | 'quick' | null */
let toastTimer      = null;

/* ═══════════════════════════════════════════════════════════════
   UTILITIES
   ═══════════════════════════════════════════════════════════════ */

/**
 * Compute a letter grade from a numeric mark.
 * A+ = 90+, A = 80+, B = 70+, C = 60+, D = 50+, F = below 50
 */
function getGrade(marks) {
    if (marks >= 90) return { label: 'A+', cls: 'grade-a-plus' };
    if (marks >= 80) return { label: 'A',  cls: 'grade-a'     };
    if (marks >= 70) return { label: 'B',  cls: 'grade-b'     };
    if (marks >= 60) return { label: 'C',  cls: 'grade-c'     };
    if (marks >= 50) return { label: 'D',  cls: 'grade-d'     };
    return              { label: 'F',  cls: 'grade-f'     };
}

/**
 * Get a color hex for a bar based on marks value.
 * Used in the visualization bar fill.
 */
function marksColor(marks) {
    if (marks >= 90) return '#3fb950';
    if (marks >= 75) return '#2dd4bf';
    if (marks >= 60) return '#a78bfa';
    if (marks >= 50) return '#f0c040';
    return '#f85149';
}

/**
 * Show a toast notification.
 * @param {string} message
 * @param {'success'|'error'|'info'} type
 */
function showToast(message, type = 'info') {
    toast.textContent = message;
    toast.className = `toast toast-${type} show`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

/**
 * Set the status bar text and style.
 * @param {string} text
 * @param {'idle'|'merge'|'quick'|'error'|'loading'} state
 */
function setStatus(text, state = 'idle') {
    statusBar.className = `status-bar status-${state}`;
    statusText.textContent = text;
}

/**
 * Enable / disable sort buttons based on student count.
 */
function updateSortButtons(count) {
    mergeSortBtn.disabled = count === 0;
    quickSortBtn.disabled = count === 0;
}

/* ═══════════════════════════════════════════════════════════════
   SLIDER SYNC  (marks slider ↔ number input)
   ═══════════════════════════════════════════════════════════════ */

function syncSliderFromInput() {
    const v = parseInt(marksInput.value, 10);
    if (!isNaN(v) && v >= 0 && v <= 100) {
        marksSlider.value = v;
        marksDisplay.textContent = v;
    }
}

function syncInputFromSlider() {
    marksInput.value = marksSlider.value;
    marksDisplay.textContent = marksSlider.value;
}

marksSlider.addEventListener('input', syncInputFromSlider);
marksInput.addEventListener('input', syncSliderFromInput);

/* Initialise display */
marksDisplay.textContent = marksSlider.value;
marksInput.value = marksSlider.value;

/* ═══════════════════════════════════════════════════════════════
   TABLE RENDERING
   ═══════════════════════════════════════════════════════════════ */

/**
 * Render a list of students into the table.
 * @param {Array}   students   - Student objects { name, roll, marks }
 * @param {boolean} isSorted   - If true, apply highlight + rank classes
 * @param {string}  algo       - 'merge' | 'quick' | null
 */
function renderTable(students, isSorted = false, algo = null) {
    tableBody.innerHTML = '';

    if (students.length === 0) {
        tableBody.innerHTML = `
            <tr class="empty-row" id="emptyRow">
              <td colspan="5">
                <div class="empty-state">
                  <div class="empty-icon">🎓</div>
                  <p>No students yet. Add one using the form!</p>
                </div>
              </td>
            </tr>`;
        studentCount.textContent = '0 students';
        updateSortButtons(0);
        setStatus('Add students to get started.');
        return;
    }

    const sortedClass = algo === 'quick' ? 'sorted-row sorted-by-quick' : 'sorted-row';

    students.forEach((s, i) => {
        const grade = getGrade(s.marks);
        const rank  = i + 1;

        /* Color the marks progress bar */
        const barColor     = marksColor(s.marks);
        const barWidthPct  = s.marks;

        /* Rank class for top 3 (when sorted) */
        let rankClass = '';
        if (isSorted) {
            if (rank === 1) rankClass = 'rank-1';
            else if (rank === 2) rankClass = 'rank-2';
            else if (rank === 3) rankClass = 'rank-3';
        }

        const rowClass = isSorted ? `${sortedClass} ${rankClass}` : rankClass;
        const rankLabel = isSorted ? (rank <= 3 ? ['🥇','🥈','🥉'][rank-1] : rank) : rank;

        const tr = document.createElement('tr');
        tr.className = rowClass.trim();
        tr.style.animationDelay = `${i * 0.04}s`;
        tr.innerHTML = `
            <td>${rankLabel}</td>
            <td>${escapeHtml(s.name)}</td>
            <td>${s.roll}</td>
            <td>
              <div class="marks-cell">
                <div class="marks-bar-wrap">
                  <div class="marks-bar-fill"
                       style="width:${barWidthPct}%; background:${barColor}"></div>
                </div>
                <span class="marks-val">${s.marks}</span>
              </div>
            </td>
            <td><span class="grade-badge ${grade.cls}">${grade.label}</span></td>
        `;
        tableBody.appendChild(tr);
    });

    studentCount.textContent = `${students.length} student${students.length !== 1 ? 's' : ''}`;
    updateSortButtons(students.length);
}

/**
 * Minimal HTML escape to prevent XSS in student names.
 */
function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

/* ═══════════════════════════════════════════════════════════════
   VISUALIZATION (bar chart)
   ═══════════════════════════════════════════════════════════════ */

/**
 * Render a simple bar chart of sorted marks.
 * @param {Array}  students
 * @param {string} algo  - 'merge' | 'quick'
 */
function renderVisualization(students, algo) {
    const maxMarks = 100;
    const maxHeight = 130;   /* px, maximum bar height */

    /* Build info line */
    const algoLabel = algo === 'merge' ? '⚙ Merge Sort' : '⚡ Quick Sort';
    const complexity = algo === 'merge'
        ? 'O(n log n) time, O(n) space — Stable'
        : 'O(n log n) avg time, O(log n) space — In-place';
    vizSortInfo.textContent = `${algoLabel} · ${complexity} · Sorted ${students.length} students by Marks ↓`;

    vizTitle.textContent = `${algoLabel} — Mark Distribution`;

    vizBars.innerHTML = '';
    const barClass = algo === 'quick' ? 'bar-sorted-q' : 'bar-sorted';

    students.forEach((s, i) => {
        const h      = Math.max(8, Math.round((s.marks / maxMarks) * maxHeight));
        const color  = marksColor(s.marks);
        const delay  = i * 0.05;

        const bar = document.createElement('div');
        bar.className = 'viz-bar';
        bar.style.animationDelay = `${delay}s`;
        bar.innerHTML = `
            <span class="viz-bar-val" style="color:${color}">${s.marks}</span>
            <div class="viz-bar-fill ${barClass}"
                 style="height:${h}px; background:${color}"
                 title="${escapeHtml(s.name)} — Marks: ${s.marks}">
            </div>
            <span class="viz-bar-label">${escapeHtml(s.name.split(' ')[0])}</span>
        `;
        vizBars.appendChild(bar);
    });

    vizPanel.hidden = false;
    vizPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

/* Close visualization */
closeVizBtn.addEventListener('click', () => {
    vizPanel.hidden = true;
});

/* ═══════════════════════════════════════════════════════════════
   API CALLS
   ═══════════════════════════════════════════════════════════════ */

/**
 * Fetch all students and render in insertion order.
 */
async function loadStudents() {
    try {
        const res  = await fetch(`${API}/students`);
        const data = await res.json();
        currentSortAlgo = null;
        renderTable(data, false, null);
        if (data.length > 0) {
            setStatus(`${data.length} student${data.length !== 1 ? 's' : ''} loaded. Ready to sort.`);
        }
    } catch (err) {
        setStatus('⚠ Cannot connect to server. Is it running?', 'error');
        console.error('loadStudents error:', err);
    }
}

/**
 * Add a student via POST /students.
 */
async function addStudent(name, roll, marks) {
    const res = await fetch(`${API}/students`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ name, roll, marks }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add student.');
    return data;
}

/**
 * Call a sort endpoint and render results.
 * @param {'merge'|'quick'} algo
 */
async function sortStudents(algo) {
    const btn = algo === 'merge' ? mergeSortBtn : quickSortBtn;
    const label = algo === 'merge' ? '⚙ Merge Sort' : '⚡ Quick Sort';

    /* Loading state */
    btn.innerHTML = `<span class="spinner"></span> Sorting…`;
    btn.disabled = true;
    setStatus(`Running ${label}…`, 'loading');

    try {
        const res  = await fetch(`${API}/sort/${algo}`);
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || `Sort failed.`);

        currentSortAlgo = algo;
        renderTable(data, true, algo);
        renderVisualization(data, algo);

        const statusState = algo === 'merge' ? 'merge' : 'quick';
        setStatus(
            `✔ ${label} complete — ${data.length} students sorted by Marks ↓`,
            statusState
        );
        showToast(`${label} applied successfully!`, 'success');

    } catch (err) {
        setStatus(`✖ ${label} error: ${err.message}`, 'error');
        showToast(err.message, 'error');
        console.error('sortStudents error:', err);
        await loadStudents();   /* Reload original order */
    } finally {
        /* Restore button */
        if (algo === 'merge') {
            btn.innerHTML = '⚙ Merge Sort';
        } else {
            btn.innerHTML = '⚡ Quick Sort';
        }
        btn.disabled = false;
        updateSortButtons(tableBody.querySelectorAll('tr:not(.empty-row)').length);
    }
}

/**
 * Clear all students.
 */
async function clearAll() {
    if (!confirm('Clear all students? This cannot be undone.')) return;
    try {
        await fetch(`${API}/students`, { method: 'DELETE' });
        currentSortAlgo = null;
        vizPanel.hidden = true;
        renderTable([], false, null);
        setStatus('All students cleared.', 'idle');
        showToast('All students removed.', 'info');
    } catch (err) {
        showToast('Failed to clear students.', 'error');
    }
}

/* ═══════════════════════════════════════════════════════════════
   FORM HANDLING
   ═══════════════════════════════════════════════════════════════ */

function showFormError(msg) {
    formError.textContent = msg;
    formError.hidden = false;
}

function hideFormError() {
    formError.hidden = true;
}

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideFormError();

    const name  = nameInput.value.trim();
    const roll  = parseInt(rollInput.value, 10);
    const marks = parseInt(marksInput.value, 10);

    /* Client-side validation */
    if (!name) {
        showFormError('Please enter the student name.');
        nameInput.focus();
        return;
    }
    if (isNaN(roll) || roll < 1 || roll > 9999) {
        showFormError('Roll number must be between 1 and 9999.');
        rollInput.focus();
        return;
    }
    if (isNaN(marks) || marks < 0 || marks > 100) {
        showFormError('Marks must be between 0 and 100.');
        marksInput.focus();
        return;
    }

    /* Disable button during request */
    addBtn.disabled = true;
    addBtn.innerHTML = `<span class="spinner"></span> Adding…`;

    try {
        await addStudent(name, roll, marks);
        showToast(`${name} added successfully!`, 'success');
        form.reset();
        marksSlider.value = 75;
        marksInput.value  = 75;
        marksDisplay.textContent = 75;
        await loadStudents();
    } catch (err) {
        showFormError(err.message);
        showToast(err.message, 'error');
    } finally {
        addBtn.disabled = false;
        addBtn.innerHTML = `<span class="btn-icon">+</span> Add Student`;
    }
});

/* ── Load demo data ─────────────────────────────────────────── */
loadDemoBtn.addEventListener('click', async () => {
    loadDemoBtn.disabled = true;
    loadDemoBtn.textContent = 'Loading…';
    try {
        for (const s of DEMO_STUDENTS) {
            await addStudent(s.name, s.roll, s.marks);
        }
        await loadStudents();
        showToast('6 demo students loaded!', 'success');
    } catch (err) {
        showToast('Error loading demo data: ' + err.message, 'error');
    } finally {
        loadDemoBtn.disabled = false;
        loadDemoBtn.textContent = 'Load 6 Demo Students';
    }
});

/* ── Sort buttons ───────────────────────────────────────────── */
mergeSortBtn.addEventListener('click', () => sortStudents('merge'));
quickSortBtn.addEventListener('click', () => sortStudents('quick'));

/* ── Clear all ──────────────────────────────────────────────── */
clearAllBtn.addEventListener('click', clearAll);

/* ═══════════════════════════════════════════════════════════════
   INIT
   ═══════════════════════════════════════════════════════════════ */
loadStudents();
